%   This MATLAB program is used to find Stein equations
 %   for Gaussian polynomial Random variables.
 %   and it is used for computation in the article
 %   "Stein operators for Gaussian polynomials in linear control theory"
 %   by Ehsan Azmoodeh, Dario Gasbarra and Robert Gaunt.
 %   If you use it in your research work, please  cite the paper.
 %   Copyright (C) 2019 Dario Gasbarra         dario.gasbarra@helsinki.fi

 %  This program is free software: you can redistribute it and/or modify
 %  it under the terms of the version 3 of the  GNU General Public License as published by
 %  the Free Software Foundation.

 %   This program is distributed in the h ope that it will be useful,
 %  but WITHOUT ANY WARRANTY; without even the implied warranty of
 %   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 %   GNU General Public License for more details.

 %  You should have received a copy of the GNU General Public License
 %  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
%%%%%% first 0...n+1 Gaussian moments
%digits(1024)
%digits(2048)
%digits(4096)
digits(8192)
%digits(16384)
%digits(262144)
%digits(1048576)
nn=1000;
n=sym(nn);
Nmoment=zeros(1,2*nn,'sym');
Nmoment(2:2:(2*nn))= cumprod(sym(1:2:(2*n-1)));
Nmoment=[1 Nmoment];
isa(Nmoment,'sym')
%%%% exact Gaussian moments Nmoment(k+1)=E(N^k)%%%%%
tic
cpu=cputime;
syms x  
%h=hermite(3,x);
%h=hermite(4,x);
%h=hermite(5,x);%%%%%  target Gaussian polynomial  h(N) 
%h=hermite(6,x)
%h=hermite(8,x)
%h=x^2 + x-1
%h= hermite(20,x);
%h=x^4-517*x^3-12*x^2-47*x;
%h=hermite(8,x);

%h=x^3

h=hermite(2,x)

p=polynomialDegree(h);
%h=h-fliplr(coeffs(h,'All'))*Nmoment(1:(p+1))';
%%%%%%%%% h is a monic polynomial with E(h(N))=0;
Dh=diff(h,x)

%T=3
%m=2

T=8 
m=4


%T=5           %%%%% time horizon
%m=10          %%%% maximum degree of  polynomial coefficients
                  %%%% in the target y=h(N)
%T=11;
%m=54;
                  Q=p*m+(p-2)*T+1
                  %%%% maximum degree as  polynomial in N
%%%% C is the multiplication operator h'(N)  expressed in 
%%%% the monomial basis  note that the indexes are
%%%% shifted.... (in matlab the indexing starts from 1)   
C=zeros(Q,Q,'sym');
coeffDh=fliplr(coeffs(Dh,'All'));
for(j=1:length(coeffDh));
    if (coeffDh(j)~=0)
  C=C+diag(repmat(coeffDh(j),1,Q-j+1),j-1);
    end;
end;
 %%%% J is the pseudoinverse of the divergence operator delta
 %%%% computed directly in monomial basis
 J=zeros(Q,Q,'sym');
 for(k=2:Q)
    index=((k-2):(-2):0);
    J(k,1+index)=cumprod(sym([ 1 index(1:(length(index)-1)) ]));   
 end;    
 A=J*C;
 %%%% note  when  h is an even Hermite polynomial,
 %%%% the derivative Dh is an odd Hermite polynomial 
 %%%% which has 0-order term = 0,  that's why 
 %%%% after multiplication by Dh in this case we obtain only terms with positive order
 %%%% and in such case the 1st column of A =0 as the 1st row.
 if false
B=zeros(1+m,Q,'sym');
B(1,1)=1;
poly=1;
 for(j=1:m)
  poly=expand(poly*h); 
  c0=sym(fliplr(coeffs(poly,'All')));
  B(j+1,1:length(c0))=c0;
 end;
 else
 %%%%%%% here we use direcly convolution of polynomial coefficients 
 %%%%%%% to compute the matrix B of coefficients of the first m
 %%%%%%% powers of the target polynomial
B=zeros(1+m,Q,'sym');
B(1,1)=1; %%%%% it corresponds to 0-th power
poly=1;   %%%%% it corresponds to 0-th power  
hcoeff=coeffs(h,'all') ;
for(j=1:m)
   poly=symconv(poly,hcoeff); 
   c0=fliplr(poly);
   B(j+1,1:length(c0))=c0;
end;    
 end
 %%%% this is in monomial basis !!!!
 %%%%   h(x)^j = sum_k  B(j,k) x^k
 %%%%  we check whether a polynomial  in K[N]
 %%%%% belongs to the subring  K[h(N)]
 %%%% to check whether    sum_k  c_k  x^k= sum_j  a_j h(x)^j
 %%%% for some  a_j
 %%%% it is equivalent to    c_k= sum_j  a_j B(j,k)
 %%%%  i.e.  solving  c=a B
 %%%%  range B gives the polynomial coefficients in monomial basis
 %%%%  of   K[h(N)]
 
 p_0=h;   %%%% here  we can have a more general zero order term
 c0=fliplr(coeffs(p_0,'all'));  %%%% check the order !!!!
 %c0=(fliplr(coeffs(h,'all')));
 v0=zeros(Q,1);
 v0(1:length(c0))=c0;   %%%%  polynomial coefficients of target
go_on=true;
t=0;
v=v0;
G=B';
while go_on
    t=(t+1)
    v=(A'*v);   
    u=linsolve(G,-v);   %%%%%%%%%%%%  G*u=-v
    go_on=((t<T)&&(isinf(u(1))));
    if go_on
     G=[A'*G B'];
    end
    end
check=(G*u+v)'         %%%%%%%%% we should have check = 0
v1=v;
%u1=u;
%%%%%%% here we fix the expectation terms..... 10-08-2019 
 v=v0;
 index=(1:(m+1));
 for(tau=1:(t-1))
   v=(B'*u(index)+A'*v);
  %%% v'
   u(index(1))=(u(index(1))-Nmoment(1:Q)*v); %%%% subtracting the mean before applying the operator A'
   index=index+(m+1);
 end;
 check=(G*u+v1)'
 
 m1=m;
 while(all(u((1+m1)*(1:t))==0)&&(m1>0))
   m1=(m1-1);
 end 
 m1
 
 nullG=null(G);
 if (size(nullG,2)<t)
   nullG=[];
   nulld=0;
 else
 nullG=nullG(:,(t:end));
 nulld=size(nullG,2);
  v=zeros(Q,nulld);
  index=1:(m+1);
  for(tau=1:(t-1))
   v=(B'*nullG(index,:)+A'*v);
   nullG(index(1),:)=(nullG(index(1),:)-Nmoment(1:Q)*v);
   index=index+(m+1);
  end;
 end; 
 elapsedtime=toc
 cpu=cputime-cpu
    
 pretty(u')
 nullG'
 t
 
 S=printSteineq([1;u],1,m,strcat('stein_eq_',num2str(p),'_',num2str(T),'_',num2str(1),'_',num2str(m),'_',date,'.tex'))
 
 %%%%%%%%% writing the Stein eq in latex and symbolic polynomial forms
 uu=[1 ; u ];
 %uu=[1; u+theta*nullG]; %%%% we can add a null solution, theta has size
 %1 x nulld
 uu=uu/gcd(uu);
 fid=fopen(strcat('new_riccati_',num2str(p),'_',num2str(m),'_',num2str(t),'_',date,'.tex'),'w');
 syms y D
 stein_eq=uu(1)*y;
 if (uu(1)==1)
  fprintf(fid,' &  y');
  % fprintf(fid,srtcat(' & ',latex(p_0))); 
     else    
 fprintf(fid,' & %s y',uu(1));
 %fprintf(fid,srtcat(' & %s ',latex(p_0)),uu(1)); 
 end
 index=(2:(2+m));
 stein_eq=stein_eq+poly2sym(flipud(uu(index)),y)*D;
 %latex(poly2sym(flipud(uu(index))))
 fprintf(fid,'& %s\n  & \\\\ ',strcat('+(',latex(poly2sym(flipud(uu(index)),y)),')\partial' ));
 for(s=2:t)
 index=index+(1+m); 
 %latex(poly2sym(flipud(uu(index))))
 stein_eq=stein_eq+poly2sym(flipud(uu(index)),y)*D^s ;
   fprintf(fid,'& %s\n  & \\\\ ',strcat('+(',latex(poly2sym(flipud(uu(index)),y)),')\partial^{',num2str(s),'}' ))  ;
 end;
 fclose(fid);
save(strcat('new_riccati_',num2str(p),'_',num2str(m),'_',num2str(t),'_',date));   %%%% saving the result in matlab format
pretty(stein_eq)
nulld
 
%%%%% we check the Stein equation for all power test functions f(y)=y^j,  j=1,...,K 
coeffsp=fliplr(coeffs(stein_eq,D,'All'));
%%%%% checking the backward Stein chain property
q=sym(nan(1,t+1));
q(t+1)=(simplifyFraction(subs(coeffsp(t+1),y,h)/Dh));  %%%% p_n(h(N)) in  < Dh(N)>
%%% this should be a polynomial and not a rational function
for(s=t:(-1):1)
q(s)=(simplifyFraction((q(s+1)*x-diff(q(s+1))+subs(coeffsp(s),y,h))/Dh));  %%%%  in  < Dh(N)>
end;
pretty(q)
pretty(q(1))
%%%%%%%%%%  if  everything is correct
%%%%%%%%%%  at every stage q is a polynomial and not a rational function
%%%%%%%%%% and at the final stage q(1)=0  corresponding to zero order
%%%%%%%%%% term....

%%%%%%% checking Stein equation using  moments
ordp=length(coeffsp)-1;
 K=20
K0=50
steincheck=nan(1,K,'sym');
boolecheck=nan(1,K,'sym');
for(k=1:K)
f=y^(K0+k);  %%%  we test the Stein equation on powers of the target 
steineq=(coeffsp(1)*f);
for(j=1:ordp)
    f=diff(f);
   steineq=(steineq+coeffsp(j+1)*f);
end;   
poly=expand(subs(steineq,y,h));
coefficients=(fliplr(coeffs(poly,'All')));
steincheck(k)=coefficients*Nmoment(1:length(coefficients))';
boolecheck(k)=all( Nmoment(coefficients~=0)==0);
end;
pretty(steincheck) 
boolecheck
%polynomialDegree(q)  %%% gives error if any  q component  is  a rational function and  not a polynomial

%%%%%%%%%%%%%% more checks
stein=y;
index=1:(m+1);
for(s=1:t)
    stein=stein+poly2sym(flipud(u(index)),y)*D^s;
    index=index+(m+1);
end;    
coeffstein=fliplr(coeffs(stein,D,'All'));
pretty(simplifyFraction(subs(coeffstein(t+1),y,h)/Dh))

checkmoment=sym([0 nan(1,t-1)]);
qpoly=sym(nan(1,t+1));
ppoly=sym(nan(1,t+1));
index=((m+1)*(t-1)+(1:(m+1)));
ppoly(t+1)=poly2sym(flipud(u(index)),y);
qpoly(t+1)=simplifyFraction(subs(ppoly(t+1),y,h)/Dh);
for(tau=t:(-1):2)
index=index-(m+1);    
ppoly(tau)=poly2sym(flipud(u(index)),y);
rpoly=(x*qpoly(tau+1)-diff(qpoly(tau+1))+subs(ppoly(tau),y,h));
coeffsr=fliplr(coeffs(rpoly,'All'));
checkmoment(tau)=Nmoment(1:length(coeffsr))*coeffsr';  %%% it should have zero-mean
qpoly(tau)=simplifyFraction(rpoly/Dh);
pretty(qpoly(tau));
end;
ppoly(1)=h;
qpoly(1)=simplifyFraction((x*qpoly(2)-diff(qpoly(2))+h)/Dh);  %%%% should be = 0 

pretty(qpoly)
pretty(checkmoment)

index=((m+1)*(t-1)+(1:(m+1)));
vv=B'*u(index);
uuu=linsolve(B',vv);
uuu'*B-vv'

AA=sym(nan(Q,Q,t));
AA(:,:,1)=A;
for(tau=2:t)
 AA(:,:,tau)=AA(:,:,tau-1)*A;   
end;    
%%%%% taking powers of the A matrix

w=AA(:,:,t)'*v0;
 index=1:(m+1);
 for(tau=(t-1):(-1):1)
     w=w+AA(:,:,tau)'*B'*u1(index);
     index=index+(m+1);
 end;    
 pretty((B'*u1(index)+w)')   %%%%% this should be = 0 
 
 w=AA(:,:,t)'*v0;
 index=1:(m+1);
 for(tau=(t-1):(-1):1)
     w=w+AA(:,:,tau)'*B'*u(index);
     index=index+(m+1);
 end;    
 pretty((B'*u(index)+w)')   %%%%% this should be = 0
 spy(AA(:,:,t))
 p*m+(p-2)*t+1

%%%% divergence operator in matrix form
 delta=zeros(Q,Q)+diag(ones(1,Q-1),-1)-diag(1:(Q-1),1);
 %%%%%% target coefficients
 coeffsh=zeros(Q,1);
 coeffsh(1:p+1)=fliplr(coeffs(h,'All'));
 
 %%%%%%%% we check that the Stein chain is a backward Stein chain
 %%%%%%%% using the vector representation with linear algebra
index=((m+1)*(t-1)+(1:(m+1)));
ppoly=B'*u(index); 
qpoly=linsolve(C',ppoly);    %%% division by Dh(N)
%%%% C'*poly2=poly1         %%%  C is the multiplication by Dh
(C'*qpoly-ppoly)'   %%%%%% =0 
for(tau=t:(-1):2)
    index=index-(m+1);
  ppoly=delta*qpoly+B'*u(index);
 qpoly=linsolve(C',ppoly);   %%% division by  Dh(N)
 (C'*qpoly-ppoly)'
end;
(delta*qpoly+coeffsh)'
%%%%%% we use  linear algebra to  divide the polynomials in their
%%%%%% vector representation  













