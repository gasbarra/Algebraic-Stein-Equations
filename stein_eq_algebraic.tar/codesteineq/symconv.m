%   This MATLAB program is used to find Stein equations
 %   for Gaussian polynomial Random variables.
 %   and it is used for computation in the article
 %   "Stein operators for Gaussian polynomials in linear control theory"
 %   by Ehsan Azmoodeh, Dario Gasbarra and Robert Gaunt.
 %   If you use it in your research work, please  cite the paper.
 %   Copyright (C) 2019 Dario Gasbarra         dario.gasbarra@helsinki.fi

 %  This program is free software: you can redistribute it and/or modify
 %  it under the terms of the version 3 of the  GNU General Public License as published by
 %  the Free Software Foundation.

 %   This program is distributed in the h ope that it will be useful,
 %  but WITHOUT ANY WARRANTY; without even the implied warranty of
 %   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 %   GNU General Public License for more details.

 %  You should have received a copy of the GNU General Public License
 %  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
function c = symconv(a,b)
%%%% convolution of two symbolic row vectors
%%%% it is just like the matlab function conv, 
%%%% which however does not take symbolic vectors
%%%% only numeric
n=length(a)+length(b)-1;
c=zeros(1,n,'sym');    
parfor(k=1:n)   %%%% with parallel toolbox
%%%% for(k=1:n)  %%%% without parallel toolbox
   index=(max(1,k+1-length(b)):min(length(a),k));
       c(k)=a(index)*b(k-index+1)';
      %for(j=max(1,k+1-length(b)):min(length(a),k))
      % c(k)=c(k)+a(j)*b(k-j+1)
      %end       
end       
end
