%   This MATLAB program is used to find Stein equations
 %   for Gaussian polynomial Random variables.
 %   and it is used for computation in the article
 %   "Stein operators for Gaussian polynomials in linear control theory"
 %   by Ehsan Azmoodeh, Dario Gasbarra and Robert Gaunt.
 %   If you use it in your research work, please  cite the paper.
 %   Copyright (C) 2019 Dario Gasbarra         dario.gasbarra@helsinki.fi

 %  This program is free software: you can redistribute it and/or modify
 %  it under the terms of the version 3 of the  GNU General Public License as published by
 %  the Free Software Foundation.

 %   This program is distributed in the h ope that it will be useful,
 %  but WITHOUT ANY WARRANTY; without even the implied warranty of
 %   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 %   GNU General Public License for more details.

 %  You should have received a copy of the GNU General Public License
 %  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
%%%%%% first 0...n+1 Gaussian moments
%digits(1024)
%digits(2048)
%digits(4096)
%digits(8192)
digits(16384)
%digits(262144)
%digits(1048576)
%%%%  We need the Gaussian moments
%%%%  the  polynomial basis consists of   products of centered univariate
%%%%  powers.
nn=1000;
n=sym(nn);
Nmoment=zeros(1,2*nn,'sym');
Nmoment(2:2:(2*nn))=cumprod(sym(1:2:(2*n-1)));
Nmoment=[1 Nmoment];
%isa(Nmoment,'sym')
%%%% exact Gaussian moments Nmoment(k+1)=E(N^k)%%%%%
tic
cpu=cputime;

d=2;      %%%%% dimension of Gaussian space
%T=d;      %%%%% time horizon
%m=d-1;      %%%% maximum degree of  polynomial coefficients
          %%%% in the target y=h(N)
        
X=sym('X',[1 d]);
h=prod(X)
%h=X(1)^3
%m=2
%T=3
%h=hermite(6,X(1))
m=5          
T=7
%m=5         
%T=4
%d=4
 %T=5  
%mu=sym([ 0  4 ])
%h=X(1)^4
%h=hermite(4,X(1))
%h=(X(1)+X(2)+X(3) +X(4))
%h= ( X(1)^2 - X(2)^2)/2
%h=X(1)^4
%h=(X(1)*X(2)+mu(1)*X(2)+mu(2)*X(1));
%h= X(1)*X(2)^2*X(3)^3 + X(1)+X(2)^2+X(3)^3-1
%%%%%% each  X(1)^k   is  intepreted  as  p_k(X) = ( X^k- E(X^k) ) for k>0 
%%%%%%%%%%%  and   p_0(X)=X^0=1.
%%%%%% also  the univariate  delta^{-1}( p_k(X) ) needs also to be
%%%%%% computed, it is not as for Hermite polynomials !

%h=X(1)*X(2)

p=zeros(1,d);
%Dh=zeros(1,d,'sym');
for(j=1:d)
p(j)=polynomialDegree(h,X(j));
%Dh(j)=simplify(diff(h,X(j)));  
%%%% the derivation rule is not the same as for monomials and Hermite
%%%% polynomials :   D X^n= n X^(n-1)   and  Dhermite(n,X)=n Hermite(n-1,X)
%%% instead we have the derivation rule for   p_k(X)=(X^k -E(N^{j})
%%%%%%  D p_k(X)= k X^(k-1) = k p_(k-1)(X) + k E(N^(k-1))   if   k>= 2
%%%%%  D p_0(X)=0        and  D p_1(X)=D X= 1
end;
maxp=max(p)
p
%Dh
if (d==1)
  Q=p*m+(p-2)*T+1;
else
Q=(p*(m+T)+1);
end
maxQ=max(Q);
cumprodQ=cumprod(Q);
Qmulti=cumprodQ(d);
cprodQ=[1  cumprodQ(1:(d-1)) ]';
%multi=sym(0:(Q(1)-1));
%for(j=2:d)
%  multi=sym(combvec(multi,0:(Q(j)-1)))  
%end;    
multi=(0:(Q(1)-1));
for(j=2:d)
  multi=(combvec(multi,0:(Q(j)-1)))  
end;    
hvector=zeros(1,Qmulti);
if (d==1)
   coef=fliplr(coeffs(h,'all'))
   hvector(1:length(coef))=coef; 
else    
[coef,mono]=coeffs(h,X,'all');
for(j=1:d)
   coef=flip(coef,j);
   mono=flip(mono,j);
end    
combo=1:(p(1)+1);
for(j=2:d)
    combo=combvec(combo,1:(p(j)+1));
end;
coef=reshape(coef,1,prod(1+p));
mono=reshape(mono,1,prod(1+p));
%%% sum(coef.*mono,'all')
%%% this gives a d-dimensional array, for each dimension k
%%% the size is (1+ maximum degree of h(X) w.r.t. X_k) 
%prod(X.^((combo-1)'),2)  
%multi(:,cprodQ'*(combo-1)+1)
%combo-1;
hvector(cprodQ'*(combo-1)+1)=coef;
end;

%%% here we give the "true" expression for h
trueh=sym(0);
%%%% coefficients given in product of centered powers basis
for(k=find(hvector))
 trueh=trueh+hvector(k)*prod(X.^(multi(:,k)')-Nmoment(multi(:,k)+1));
end;
trueh=simplify(trueh)

Dhmatrix=gradient(hvector,cprodQ,multi);
Dhmatrix(:,1)=Dhmatrix(:,1)+sum((multi>0).*Nmoment(1+multi).*Dhmatrix,2);

%%%%% we work all the time in multivariate Hermite 
%%%%% polynomial basis  the rule of derivation is the
%%% same for monomials or multivariate Hermite polynomials
 
 %%%% J is the pseudoinverse of the univariate divergence operator delta
 %%%% computed directly in centered monomial basis
 J=zeros(maxQ,maxQ,'sym');
 for(k=2:maxQ)
    index=((k-2):(-2):0);
    J(k,1+index)=cumprod(sym([1 index(1:(length(index)-1))]));   
 end
 J(:,1)=J(:,1)+J*[0 Nmoment(2:maxQ)]';
 %%% now it is in centered monomial basis 

modifiedProd=zeros(maxQ,1+maxp*m,maxQ+maxp*m,'sym');
modifiedProd(1,:,1:(1+maxp*m))=eye(1+maxp*m,'sym');
for(j=1:(maxQ-1))
    modifiedProd(j+1,1,j+1)=sym(1);
    for(l=(1:(maxp*m)))   
     modifiedProd(j+1,l+1,1+j+l)=sym(1);
     modifiedProd(j+1,l+1,1)=(Nmoment(l+j+1)-Nmoment(l+1)*Nmoment(j+1));
     if(j==l)
      modifiedProd(j+1,j+1,j+1)=-2*Nmoment(j+1);   
     else
     modifiedProd(j+1,l+1,j+1)=-Nmoment(l+1);
     modifiedProd(j+1,l+1,l+1)=-Nmoment(j+1);
     end;     
    end;
end;
% structural matrix of products (X^k-mu_k)(X^j-mu_j)= X^(k+j)-mu_j X^k-mu_k X^j + mu_j mu_k=
% = (X^(k+j)-mu_(k+j) )- mu_k ( X^j-mu_j) -mu_j (X^k-mu_k)+ (mu_(k+j)-mu_k mu_j)

%%%%%%%%%%%% the loop can run in parallel on a cluster %%%%%%%%%%%%%%%%%
A=zeros(Qmulti,Qmulti,'sym');
for(k=1:d)
   parfor(l=(cprodQ(k)+1):Qmulti) 
    if(multi(k,l)>0)   
        % invdelta=zeros(1,Qmulti,'sym');
         non0=find(J(1+multi(k,l),:));
        % invdelta(l+cprodQ(k)*(non0-1-multi(k,l)))=J(1+multi(k,l),non0);
        %% invdelta=J(1+multi(k,l),non0)
        %% index=l+cprodQ(k)*(non0-1-multi(k,l));
         A(l,:)=A(l,:)+sym(multi(k,l)/sum(multi(:,l),1))*prodMultiModified(J(1+multi(k,l),non0),l+cprodQ(k)*(non0-1-multi(k,l)),Dhmatrix(k,:),modifiedProd,multi,cprodQ);
    end;
  end;
  end;
      
%%%%%%%%%% A  is the Gamma matrix
%%%%%% B is the Lambda matrix
B=zeros(1+m,Qmulti,'sym');
B(1,1)=sym(1);
B(2,:)=hvector; 
for(k=2:m)
    B(k+1,:)=prodMulti(B(k,:),hvector,modifiedProd,multi,cprodQ);
end;

 %%%% this is in product of centered monomial basis !!!!
 %%%%   prod_j ( X_j^{k_j}- E(N^{k_j} ) = sum_l  B(k,l) prod_j ( X_l^{l_j}- E(N^{l_j} )
 %%%%  we check whether a polynomial  in K[N]
 %%%%% belongs to the subring  K[h(N)]
 %%%% to check whether    sum_k  c_k  x^k= sum_j  a_j h(x)^j
 %%%% for some  a_j
 %%%% it is equivalent to    c_k= sum_j  a_j B(j,k)
 %%%%  i.e.  solving  c=a B
 %%%%  range B gives the polynomial coefficients in  product of centered monomial basis
 %%%%  of   K[h(N)]
   
 c0=hvector;  %%%% we take as zero order polynomial the target 
              %%%% or some power of it
 
 v0=zeros(Qmulti,1);
 v0(1:length(c0))=c0;   %%%%  polynomial coefficients of target
go_on=true;
t=0;
v=v0;
G=B';
while go_on
    t=(t+1)
    v=(A'*v);   
    u=linsolve(G,-v);   %%%%%%%%%%%%  G*u=-v
    go_on=((t<T)&&(isinf(u(1))));
    if go_on
     G=[A'*G B'];
    end
    end
check=(G*u+v)'         %%%%%%%%% we should have check = 0
v1=v;
%%%%%%% here we fix the expectation terms..... 10-08-2019 
 v=v0;
 index=(1:(m+1));
 for(tau=1:(t-1))
   v=(B'*u(index)+A'*v);
   u(index(1))=(u(index(1))-v(1)); %%%% subtracting the mean before applying the operator A' 
   index=index+(m+1);
 end;
 check=(G*u+v1)'
  
 nullG=null(G);
 if (size(nullG,2)<t)
   nullG=[];
   nulld=0;
 else
 nullG=nullG(:,(t:end));
 nulld=size(nullG,2);
  v=zeros(Q,nulld);
  index=1:(m+1);
  for(tau=1:(t-1))
   v=(B'*nullG(index,:)+A'*v);
   nullG(index(1),:)=(nullG(index(1),:)-v(1));
   index=index+(m+1);
  end;
 end; 
 elapsedtime=toc
 cpu=cputime-cpu
    
 pretty(u')
 nullG'
 t
 
 uu=[1 ; u ];
 uu=uu/gcd(uu);

save(strcat('result',date))

 filename=strcat('multi_Stein_eq_modified_',date)
 save(filename);
 S=printSteineq(uu,1,m,strcat(filename,'.tex'))
 %pretty(S)
 
if false
ustar=zeros(size(u),'sym');
for(s=1:t)
     ustar(s+(s-1)*(m+1))=-nstir2k(sym(t),sym(s));    
end;    
ustar'

check=(G*ustar+v1)'

15*check(find(check~=0))
poly=multi(:,find(check~=0))
end


if false
%%%%% change of basis from monomial to hermite and back
%%% note that  det(H)=det(invH)=1
%%% obviously, the matrix is triangular and 
%%%% the diagonal elements are 1.
invHermite=zeros(maxQ,maxQ);
invHermite(1,1)=1;
for(k=1:(maxQ-1))
  invHermite(k+1,1:(k+1))=sym(fliplr(coeffs(hermite(k,X(1)),'All')))       ;  
end;    
Hermite=inv(invHermite);    
end;
