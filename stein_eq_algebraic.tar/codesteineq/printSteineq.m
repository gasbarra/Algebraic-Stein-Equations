%   This MATLAB program is used to find Stein equations
 %   for Gaussian polynomial Random variables.
 %   and it is used for computation in the article
 %   "Stein operators for Gaussian polynomials in linear control theory"
 %   by Ehsan Azmoodeh, Dario Gasbarra and Robert Gaunt.
 %   If you use it in your research work, please  cite the paper.
 %   Copyright (C) 2019 Dario Gasbarra         dario.gasbarra@helsinki.fi

 %  This program is free software: you can redistribute it and/or modify
 %  it under the terms of the version 3 of the  GNU General Public License as published by
 %  the Free Software Foundation.

 %   This program is distributed in the h ope that it will be useful,
 %  but WITHOUT ANY WARRANTY; without even the implied warranty of
 %   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 %   GNU General Public License for more details.

 %  You should have received a copy of the GNU General Public License
 %  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
function S=printSteineq(u,m_0,m,filename)
syms y D;
%%%% u is the column vector of coefficients
%%%%  with length  m_0+(m+1)*T   for some  T >= polynomial order
%%%%  m_0 >= degree of p_0(y)  and m >= max_polynomial degree.
%%%% the first m_0 elements are the coefficients 
%%%%% of the zero order polynomial coefficient p_0(y)  , starting from the coefficient of y
%%%%% ( the zero order term has no constant coefficient)
%%%%% the the next  (m+1) elements of u  are the coefficients of  p_1(y)
%%%%% starting from the constant term  1=y^0  up to power y^m
%%%%% and it continues in the same way for the next polynomial coefficients
%%%%% p_t(y) of degree <= m.
u=u/gcd(u);
Q=length(u);
index=(1:m_0);
S=(y.^(index))*u(index);
fid=fopen(filename,'w');
fprintf(fid,'& %s &\n',strcat('(',latex(poly2sym(flipud([0 ; u(index)]),y)),')'));
index=(m_0+(1:(m+1)));
k=0;
while(index(end)<=Q)
k=(k+1);    
if  (any(u(index)~=0))
S=S+(y.^((0:m))*u(index))*D^k;
if (k==1)
fprintf(fid,'\\\\& %s\n & ',strcat('+(',latex(poly2sym(flipud(u(index)),y)),')\partial'));
else
  fprintf(fid,'\\\\& %s\n &  ',strcat('+(',latex(poly2sym(flipud(u(index)),y)),')\partial^{',num2str(k),'}'));
end  
end;
index=index+(m+1);
end;
fclose(fid);
end
