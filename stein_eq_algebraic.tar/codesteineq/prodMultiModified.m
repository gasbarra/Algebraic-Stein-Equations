%   This MATLAB program is used to find Stein equations
 %   for Gaussian polynomial Random variables.
 %   and it is used for computation in the article
 %   "Stein operators for Gaussian polynomials in linear control theory"
 %   by Ehsan Azmoodeh, Dario Gasbarra and Robert Gaunt.
 %   If you use it in your research work, please  cite the paper.
 %   Copyright (C) 2019 Dario Gasbarra         dario.gasbarra@helsinki.fi

 %  This program is free software: you can redistribute it and/or modify
 %  it under the terms of the version 3 of the  GNU General Public License as published by
 %  the Free Software Foundation.

 %   This program is distributed in the h ope that it will be useful,
 %  but WITHOUT ANY WARRANTY; without even the implied warranty of
 %   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 %   GNU General Public License for more details.

 %  You should have received a copy of the GNU General Public License
 %  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
function  c=prodMultiModified(a,finda,b,hermiteProd,multi,cprodQ)
%%% it computes  the product of two multivariate Hermite polynomials
%%% computed in Hermite multivariate basis 
%%% Phi_{alpha}(X_1,...,X_d)= prod_j hermite(alpha_j, X_j)
%%%%   ( sum_{alpha} a_{alpha} Phi_{alpha}(X) ) \times 
%%%( sum_{beta} b_{beta} Phi_{beta}(X) ) =
%%% sum_{gamma} c_{gamma} Phi_{gamma}(X)
%%% the product also is in Hermite multivariate basis
%%%% arguments: a,b = the vectors of coefficients
%%%% multi is a dxQ  matrix of ordered multivariate monomials
%%%% cprodQ is a dx1 vector used to map the multivariate monomials
%%%% to the vector indices
%%%% hermiteProd is a 3 order structural tensor
%%%% containing  E( h_j(X) h_k (X) h_l(X) )
[d,Q]=size(multi);
%c=zeros(1,Q,'sym');
c=zeros(1,Q);
non0=cell(1,d);
%finda=find(a);
findb=find(b);
j=0;
for(k=finda)
    j=(j+1);
    indexk=multi(:,k);
  for(l=findb)   
     indexl=multi(:,l); 
      for(s=1:d)
         product=squeeze(hermiteProd(1+indexk(s),1+indexl(s),:));
         non0{s}.p=(find(product)-1)';
         non0{s}.w=product(non0{s}.p+1)';
      end     
 powers=non0{1}.p;
 coefficients=non0{1}.w;
  for(s=2:d) 
      powers=combvec(powers,non0{s}.p);
      coefficients=combvec(coefficients,non0{s}.w);   
  end   
 indices=(cprodQ'*powers+1);
 range=find(indices<=Q);
 indices=indices(range);
 c(indices)=c(indices)+a(j)*b(l)*prod(coefficients(:,range),1); 
end       
end
end
