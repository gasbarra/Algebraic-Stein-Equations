%   This MATLAB program is used to find Stein equations
 %   for Gaussian polynomial Random variables.
 %   and it is used for computation in the article
 %   "Stein operators for Gaussian polynomials in linear control theory"
 %   by Ehsan Azmoodeh, Dario Gasbarra and Robert Gaunt.
 %   If you use it in your research work, please  cite the paper.
 %   Copyright (C) 2019 Dario Gasbarra         dario.gasbarra@helsinki.fi

 %  This program is free software: you can redistribute it and/or modify
 %  it under the terms of the version 3 of the  GNU General Public License as published by
 %  the Free Software Foundation.

 %   This program is distributed in the h ope that it will be useful,
 %  but WITHOUT ANY WARRANTY; without even the implied warranty of
 %   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 %   GNU General Public License for more details.

 %  You should have received a copy of the GNU General Public License
 %  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
function Dh=gradient(h,cprodQ,multi)
%%%% Dh is a matrix;
d=length(cprodQ);
Dh=zeros(d,length(h),'sym');
index0=find(h);
for(k=1:d)    
  index=index0-cprodQ(k);
  findex=find(index>0);
  if (~isempty(findex))
  Dh(k,index(findex))=sym(h(index0(findex)).*multi(k,index0(findex)));
  end
end;
end

