%   This MATLAB program is used to find Stein equations
 %   for Gaussian polynomial Random variables.
 %   and it is used for computation in the article
 %   "Stein operators for Gaussian polynomials in linear control theory"
 %   by Ehsan Azmoodeh, Dario Gasbarra and Robert Gaunt.
 %   If you use it in your research work, please  cite the paper.
 %   Copyright (C) 2019 Dario Gasbarra         dario.gasbarra@helsinki.fi

 %  This program is free software: you can redistribute it and/or modify
 %  it under the terms of the version 3 of the  GNU General Public License as published by
 %  the Free Software Foundation.

 %   This program is distributed in the h ope that it will be useful,
 %  but WITHOUT ANY WARRANTY; without even the implied warranty of
 %   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 %   GNU General Public License for more details.

 %  You should have received a copy of the GNU General Public License
 %  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
%digits(1024)
%digits(2048)
digits(4096)
nn=1000;
n=sym(nn);
Nmoment=zeros(1,2*nn,'sym');
Nmoment(2:2:(2*nn))= cumprod(sym(1:2:(2*n-1)));
Nmoment=[1 Nmoment];
isa(Nmoment,'sym')
%%%% exact Gaussian moments Nmoment(k+1)=E(N^k)%%%%%
tic
cpu=cputime;
syms x  
%h=hermite(3,x);
%h=hermite(4,x);
%h=hermite(5,x);%%%%%  target Gaussian polynomial  h(N) 
%h=hermite(6,x)
%h=hermite(8,x)
%h=x^2 + x-1
%h= hermite(20,x);
%h=x^4-517*x^3-12*x^2-47*x;
%h=hermite(7,x);
%h=hermite(5,x);
h=hermite(2,x);

p=polynomialDegree(h);
%h=h-fliplr(coeffs(h,'All'))*Nmoment(1:(p+1))';
%%%%%%%%% h is a monic polynomial with E(h(N))=0;
Dh=diff(h,x)
%T=24            %%%%% time horizon
%m=24          %%%% maximum degree of  polynomial coefficients
                  %%%% in the target y=h(N)
%T=10;%%%%%% first 0...n+1 Gaussian moments

%m=13;
%m_0=5  %%% we restrict the 0 order coefficients in Stein eq. to have degree <= m_0
     
%T=30;
%m=20;
%m_0=6  %%% we restrict the 0 order coefficients in Stein eq. to have degree <= m_0
   

T=8;
m=5;
terms0=1:2 %%% powers in the 0 order coefficient

m_0=length(terms0);

Q=p*m+(p-2)*T+1
                  %%%% maximum degree as  polynomial in N
%%%% C is the multiplication operator h'(N)  expressed in 
%%%% the monomial basis  note that the indexes are
%%%% shifted.... (in matlab the indexing starts from 1)   
C=zeros(Q,Q,'sym');
coeffDh=fliplr(coeffs(Dh,'All'));
for(j=1:length(coeffDh));
    if (coeffDh(j)~=0)
  C=C+diag(repmat(coeffDh(j),1,Q-j+1),j-1);
    end;
end;
 %%%% J is the pseudoinverse of the divergence operator delta
 %%%% computed directly in monomial basis
 J=zeros(Q,Q,'sym');
 for(k=2:Q)
    index=((k-2):(-2):0);
    J(k,1+index)=cumprod(sym([ 1 index(1:(length(index)-1)) ]));   
 end;    
 A=J*C;
 %%%% note  when  h is an even Hermite polynomial,
 %%%% the derivative Dh is an odd Hermite polynomial 
 %%%% which has 0-order term = 0,  that's why 
 %%%% after multiplication by Dh in this case we obtain only terms with positive order
 %%%% and in such case the 1st column of A =0 as the 1st row.
if (false)
 
B=zeros(1+m,Q,'sym');
B(1,1)=1;
poly=1;
 for(j=1:m)
  poly=expand(poly*h); 
  c0=sym(fliplr(coeffs(poly,'All')));
  B(j+1,1:length(c0))=c0;
 end;
 
 else
 
  %%%%%%% here we use direcly convolution of polynomial coefficients 
 %%%%%%% to compute the matrix B of coefficients of the first m
 %%%%%%% powers of the target polynomial
B=zeros(1+m,Q,'sym');
B(1,1)=1; %%%%% it corresponds to 0-th power
poly=1;   %%%%% it corresponds to 0-th power  
hcoeff=coeffs(h,'all') ;
for(j=1:m)
   poly=symconv(poly,hcoeff); 
   c0=fliplr(poly);
   B(j+1,1:length(c0))=c0;
end;    

end
 
 %%%% this is in monomial basis !!!!
 %%%%   h(x)^j = sum_k  B(j,k) x^k
 %%%%  we check whether a polynomial  in K[N]
 %%%%% belongs to the subring  K[h(N)]
 %%%% to check whether    sum_k  c_k  x^k= sum_j  a_j h(x)^j
 %%%% for some  a_j
 %%%% it is equivalent to    c_k= sum_j  a_j B(j,k)
 %%%%  i.e.  solving  c=a B
 %%%%  range B gives the polynomial coefficients in monomial basis
 %%%%  of   K[h(N)]
 
 %%%% p_0=h;   %%%% here  we can have a more general zero order term
 
 %m_0=5  %%% we restrict the 0 order coefficients in Stein eq. to have degree <= m_0
% powers=1:m_0;
 
 p_0=reshape(h.^(terms0),m_0,1)  
 v0=zeros(Q,m_0,'sym');
 for(l=1:m_0)
 c0=fliplr(coeffs(p_0(l),'All'));  %%%% check the order !!!!
 %c0=(fliplr(coeffs(h,'All')));
 v0(1:length(c0),l)=c0;   %%%%  polynomial coefficients of target
 end;
 
go_on=true;
t=0;
v=v0;
G=B';
while go_on
    t=(t+1)
    v=(A'*v);   
    u=linsolve(G,-v);   %%%%%%%%%%%%  G*u=-v
    go_on=((t<T)&&any(isinf(u(1,:))));
    if go_on
     G=[A'*G B'];
    end
    end
check=(G*u+v)'         %%%%%%%%% we should have check = 0
v1=v;
u1=u;
%%%%%%% here we fix the expectation terms..... 10-08-2019 
 v=v0;
 index=(1:(m+1));
 for(tau=1:(t-1))
   v=(B'*u(index,:)+A'*v);
  %%% v'
   u(index(1),:)=(u(index(1),:)-Nmoment(1:Q)*v); %%%% subtracting the mean before applying the operator A'
   index=index+(m+1);
 end;
 check=(G*u+v1)'
  
 nullG=null(G);
 if (size(nullG,2)<t)
   nullG=[];
   nulld=0;
 else
 nullG=nullG(:,(t:end));
 nulld=size(nullG,2);
  v=zeros(Q,nulld);
  index=1:(m+1);
  for(tau=1:(t-1))
   v=(B'*nullG(index,:)+A'*v);
   nullG(index(1),:)=(nullG(index(1),:)-Nmoment(1:Q)*v);
   index=index+(m+1);
  end;
 end; 
 elapsedtime=toc
 cpu=cputime-cpu
 
 %uu=[eye(m_0) ; u ]
 if (isempty(nullG))
    uu=[eye(m_0) ; u ]
 else
     uu=[ [eye(m_0) ; u ]     [zeros(m_0,nulld); nullG]];  
 end;    
 
 for(l=1:(m_0+nulld))
 uu(:,l)=uu(:,l)./gcd(uu(:,l));
 end
 pretty(u')
 nullG'
 [t nulld]
 
 
 
%%%%% here we find the Stein equations with minimal t and m
 %%%%%  we first reduce the order of the ODE
 index0=size(uu,1)-(m:(-1):0);
 index=index0;
 nul=null(uu(index,:));
 size(nul)
 steps=0;
 go_on=~isempty(nul);
 if go_on
 while (go_on)
     steps=steps+1;
     newindex= [ (index0-steps*(m+1)) index];
     nul=null(uu(newindex,:));
     size(nul)
    go_on=((~isempty(nul))&&(steps<t));
 if (go_on)
 index=newindex;
 end;
 end;
 rr=uu*null(uu(index,:));
 else
 rr=uu;
 end
 spy(rr);
 size(rr,2)
 
 %%%% and then reduce the degree of the coefficients
 
 index=[  (m:m_0)   (m_0+(m+1)*(1:t)) ]
  nul=null(rr(index,:));
 stps=0;
 go_on=~isempty(nul);
 if (go_on)
 while (go_on)
     stps=stps+1;
     newindex=union( [(m-stps):m_0   (m_0-stps+(m+1)*(1:t))], index);
     nul=null(rr(newindex,:));
     size(nul)
    go_on=((~isempty(nul))&&(stps<m));
 if (go_on)
 index=newindex;
 end;
 end;
 
 vv=rr*null(rr(index,:))
 else
   vv=rr
 end;  
 size(vv,2)
 spy(vv)
 [t-steps m-stps]
 
 %%%%% we do it again in the opposite order:
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% we first reduce m the degree of the
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% coefficients
 
 index= [ m:m_0  (m_0+(m+1)*(1:t))]
  nul=null(uu(index,:));
 stps=0;
 go_on=~isempty(nul);
 if (go_on)
 while (go_on)
     stps=stps+1;
     newindex=union( [(m-stps:m_0) (m_0-stps+(m+1)*(1:t))], index);
     nul=null(uu(newindex,:));
     size(nul)
    go_on=((~isempty(nul))&&(stps<m));
 if (go_on)
 index=newindex;
 end;
 end;
 ww=uu*null(uu(index,:))
 else
 ww=uu
 end
 null(uu(index,:))
 spy(ww)
 size(ww)
 %%%%% then we reduce the order of the ODE
 
 index0=size(ww,1)-(m:(-1):0);
 index=index;
 nul=null(ww(index,:));
 steps=0;
 go_on=~isempty(nul);
 if (go_on)
 while (go_on)
     steps=steps+1;
     newindex= [ (index0-steps*(m+1)) index];
     nul=null(ww(newindex,:));
     size(nul)
    go_on=((~isempty(nul))&&(steps<t));
 if (go_on)
 index=newindex;
 end;
 end;
 t-steps
 
 zz=ww*null(ww(index,:))
 else
 zz=ww;    
 end;
 
 spy(zz);
 size(zz)

 
 m_reduced= m-stps 
 t_reduced=t-steps
 [t_reduced, m_reduced]
 
 %%%%%%% The computation is ready 
 %%%%%%% Next we print the result
 %%%%%%% and do some  double checks
 %%%%%%% (checking the backward Stein eq.)
 
 k=1
 filename=strcat('Stein_eq_H',num2str(p),'_vv_',date,'.tex');
 Svv=printSteineq(vv(:,k),m_0,m,filename);
 %sympref('PolynomialDisplayStyle','ascend');
 pretty(Svv)
 
 filename=strcat('Stein_eq_H',num2str(p),'_zz_',date,'.tex');
 Szz=printSteineq(zz(:,k),m_0,m,filename);
 %sympref('PolynomialDisplayStyle','ascend');
 pretty(Szz)
 
 filename=strcat('Stein_eq_H',num2str(p),'_ww_',date,'.tex');
 Sww=printSteineq(ww(:,k),m_0,m,filename);
 %sympref('PolynomialDisplayStyle','ascend');
 pretty(Sww)
 
 filename=strcat('Stein_eq_H',num2str(p),'_uu_',date,'.tex');
 Suu=printSteineq(uu(:,k),m_0,m,filename);
 %sympref('PolynomialDisplayStyle','ascend');
 pretty(Suu)
 
 filename=strcat('Stein_eq_H',num2str(p),'_rr_',date,'.tex');
 Srr=printSteineq(rr(:,1),m_0,m,filename);
 %sympref('PolynomialDisplayStyle','ascend');
 pretty(Srr)
 
