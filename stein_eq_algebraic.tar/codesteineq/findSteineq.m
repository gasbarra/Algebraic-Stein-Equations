%   This MATLAB program is used to find Stein equations
 %   for Gaussian polynomial Random variables.
 %   and it is used for computation in the article
 %   "Stein operators for Gaussian polynomials in linear control theory"
 %   by Ehsan Azmoodeh, Dario Gasbarra and Robert Gaunt.
 %   If you use it in your research work, please  cite the paper.
 %   Copyright (C) 2019 Dario Gasbarra         dario.gasbarra@helsinki.fi

 %  This program is free software: you can redistribute it and/or modify
 %  it under the terms of the version 3 of the  GNU General Public License as published by
 %  the Free Software Foundation.

 %   This program is distributed in the h ope that it will be useful,
 %  but WITHOUT ANY WARRANTY; without even the implied warranty of
 %   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 %   GNU General Public License for more details.

 %  You should have received a copy of the GNU General Public License
 %  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
function [uu,t,A,B,G,cpu,elapsedtime,ok] = findSteineq(h,m_0,m,T)
%%% inputs 
%%% a symbolic univariate polynomial  h in the symbolic variable x   
%%%%%%%%% h should be a monic polynomial with E(h(N))=0;
%%% ex:  
%%% syms x
%%% h=hermite(5,x);
%%% m_0   upper bound for the degree of the 0-th order polynomial coefficient
%%% m     upper bound for the degree polynomial coefficients of positive order 
%%% T     upper bound on the order of the Stein eq.
digits(4096)
nn=1000;
n=sym(nn);
Nmoment=zeros(1,2*nn,'sym');
Nmoment(2:2:(2*nn))= cumprod(sym(1:2:(2*n-1)));
Nmoment=[1 Nmoment];
isa(Nmoment,'sym')
%%%% exact Gaussian moments Nmoment(k+1)=E(N^k)%%%%%
tic
cpu=cputime;
syms x;
p=polynomialDegree(h);
%h=h-fliplr(coeffs(h,'All'))*Nmoment(1:(p+1))';  %%% normalizing h
%%%%%%%%% h is a monic polynomial with E(h(N))=0;
Dh=diff(h,x)
terms0=1:m_0 %%% powers in the 0 order coefficient
Q=p*m+(p-2)*T+1
                  %%%% maximum degree as  polynomial in N
%%%% C is the multiplication operator h'(N)  expressed in 
%%%% the monomial basis  note that the indexes are
%%%% shifted.... (in matlab the indexing starts from 1)   
C=zeros(Q,Q,'sym');
coeffDh=fliplr(coeffs(Dh,'All'));
for(j=1:length(coeffDh));
    if (coeffDh(j)~=0)
  C=C+diag(repmat(coeffDh(j),1,Q-j+1),j-1);
    end;
end;
 %%%% J is the pseudoinverse of the divergence operator delta
 %%%% computed directly in monomial basis
 J=zeros(Q,Q,'sym');
 for(k=2:Q)
    index=((k-2):(-2):0);
    J(k,1+index)=cumprod(sym([ 1 index(1:(length(index)-1)) ]));   
 end;    
 A=J*C;
 %%%% note  when  h is an even Hermite polynomial,
 %%%% the derivative Dh is an odd Hermite polynomial 
 %%%% which has 0-order term = 0,  that's why 
 %%%% after multiplication by Dh in this case we obtain only terms with positive order
 %%%% and in such case the 1st column of A =0 as the 1st row.
if (false)
B=zeros(1+m,Q,'sym');
B(1,1)=1;
poly=1;
 for(j=1:m)
  poly=expand(poly*h); 
  c0=sym(fliplr(coeffs(poly,'All')));
  B(j+1,1:length(c0))=c0;
 end;
  
 else
 
  %%%%%%% here we use direcly convolution of polynomial coefficients 
 %%%%%%% to compute the matrix B of coefficients of the first m
 %%%%%%% powers of the target polynomial
B=zeros(1+m,Q,'sym');
B(1,1)=1; %%%%% it corresponds to 0-th power
poly=1;   %%%%% it corresponds to 0-th power  
hcoeff=coeffs(h,'all') ;
for(j=1:m)
   poly=symconv(poly,hcoeff); 
   c0=fliplr(poly);
   B(j+1,1:length(c0))=c0;
end;    

end

  %%%% this is in monomial basis !!!!
 %%%%   h(x)^j = sum_k  B(j,k) x^k
 %%%%  we check whether a polynomial  in K[N]
 %%%%% belongs to the subring  K[h(N)]
 %%%% to check whether    sum_k  c_k  x^k= sum_j  a_j h(x)^j
 %%%% for some  a_j
 %%%% it is equivalent to    c_k= sum_j  a_j B(j,k)
 %%%%  i.e.  solving  c=a B
 %%%%  range B gives the polynomial coefficients in monomial basis
 %%%%  of   K[h(N)]
 
 p_0=reshape(h.^(terms0),m_0,1)  
 v0=zeros(Q,m_0,'sym');
 for(l=1:m_0)
 c0=fliplr(coeffs(p_0(l),'All')); 
 v0(1:length(c0),l)=c0;   %%%%  polynomial coefficients of target
 end;
 
go_on=true;
t=0;
v=v0;
G=B';
while go_on
    t=(t+1)
    v=(A'*v);   
    u=linsolve(G,-v);   %%%%%%%%%%%%  G*u=-v
    go_on=((t<T)&&(any(isinf(u(1,:)))));
    if go_on
     G=[A'*G B'];
    end
end
check=(G*u+v)' ;        %%%%%%%%% we should have check = 0
ok=all(all(check==0))
if (ok)   
v1=v;
%u1=u;
%%%%%%% here we compute the  expectation terms  (constant terms in the
%%%%%%% polynomial
 v=v0;
 index=(1:(m+1));
 for(tau=1:(t-1))
   v=(B'*u(index,:)+A'*v);
   u(index(1),:)=(u(index(1),:)-Nmoment(1:Q)*v); %%%% subtracting the mean before applying the operator A'
   index=index+(m+1);
 end;
 check=(G*u+v1)'
 nullG=null(G);
 if (size(nullG,2)<t)
   nullG=[];
   nulld=0;
 else
 nullG=nullG(:,(t:end));
 nulld=size(nullG,2);
  v=zeros(Q,nulld);
  index=1:(m+1);
  for(tau=1:(t-1))
   v=(B'*nullG(index,:)+A'*v);
   nullG(index(1),:)=(nullG(index(1),:)-Nmoment(1:Q)*v);
   index=index+(m+1);
  end;
 end; 
 if (isempty(nullG))
    uu=[eye(m_0) ; u ];
 else
    uu=[ [eye(m_0) ; u ]     [zeros(m_0,nulld); nullG]];  
 end;    
 for(l=1:(m_0+nulld))
 uu(:,l)=uu(:,l)./gcd(uu(:,l));
 end
else
   uu=[]; 
   fprintf('there are no Stein equations satisfying the constraints %d %d %d\n',T,m_0,m) 
end    
 cpu=cputime-cpu
 elapsedtime=toc
end
